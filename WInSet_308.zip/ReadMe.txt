WInSet: Invariant Sets for Windows

         WInSet README file

          Version 3.0.8

WHAT'S NEW in this Version

  The following types of user systems were added:
  - 'Diff. eq. 1-3 periodic (2Pi)'
  the right hand side of the system is assumed periodic in variables
  x1, x2, x3 with period 2Pi, for convenience of calculation and plotting;
  - 'Diff. eq. 2D with quasiperiodic pert.'
  the right hand side of the system is assumed to have two-frequency
  quasi-periodic (in time) perturbation; as for systems with periodic
  perturbation (3/2 degrees of freedom) a Poincare map plot is available
  for such systems in two variants: with pseudo-random selection of the
  section plane corresponding to one of two periods, and with mean value 
  of two periods of perturbation.


WHAT'S NEW in Version 3.0.7

  Function sign(x) added to the list of elementary functions for
  user-defined systems. Help files are updated.


WHAT'S NEW in Version 3.0.6

  Help system in English was added.


WHAT'S NEW in Version 3.0.5

  New type of user-defined systems added:
  'Diff. eq.: two oscillators'
  A Map plot is implemented for this type of system:
  Poincare map for the first oscillator using the oscillation period of
  the second oscillator.

  Oscillation period of the second oscillator is calculated at the beginning
  of the map plotting. The calculation depends on additional parameters of
  computation:
     Maximal time interval for calculation of period
     Initial condition of X for the second oscillator
     Initial condition of Y for the second oscillator
  Calculation of the period is performed with zero values of the first 
  oscillator's variables.
  The period is also calculated when parameters of system are changed.

  User should control the feedback of the first oscillator on the second
  oscillator, i.e. parameters of the system should be valid for the 
  calculation and plotting.

  The oscillation period calculated during plotting is shown at the top 
  of coordinate panel: "Period=���".


WHAT'S NEW in Version 3.0.4

  Additional functions are available for user-defined systems:
  - cbrt: cubic root,
  - rnd:  pseudo random number generator within the range from zero
    to the value of the argument: rnd(a) in [0, a] 

  Fixed: various errors in plots of user systems when several WInSet
  instances worked in concurrently.


WHAT'S NEW in Version 3.0.2

  Three-dimensional rotation of 3D plots is added for ODE and maps.
    
    When current view is a 3D plot then you can press "Ctrl+G" keys
    or select menu item View | 3D Window. 
    This brings up a separate OpenGL window with the current plot
    rendered using the default viewpoint. 
    The plot in 3D Window can be rotated using arrow keys and 
    the space key returns the plot to the starting viewpoint.
    There are also several rendering options: Fog, Perspective, 
    Smoothing. These rendering options may be turned on and off
    independently.

    Before switching to a different plot type you should close 3D Window.


WHAT'S NEW in Version 3

1. Several built-in systems were added.
   A new option was added for 2D map plots:
   Basins of attraction. 
2. New types of user-defined systems were added:
   - maps on cylinder
   - diff. eq. with 3/2 degrees of freedom on cylinder
   - diff. eq. with 3/2 degrees of freedom on torus
3. Graphics may be saved now as Encapsulated
   PostScript (.EPS). This is not yet implemented
   for PDEs and fractals
4. Boxed axes are now available for 2D plots.
   Menu item "View | Boxed axes" is now checked
   by default.
5. Few bugs of user interface has been fixed.

SYSTEM REQUIREMENTS

1. MS Windows 9X/ME/NT4/2000/7/8/10 ...
2. Minimal configuration: i486DX with 32 MB RAM.
   Intel Celeron processor or better recommended.
3. Enough disk space for Windows page file expansion:
   more than 20 Mb.
4. 256 Color video mode or better.

5. Unpack ZIP file with WInSet into a folder/directory with write
   permission. You may also install and use WInSet on a USB flash drive.
    

UNINSTALLING WInSet

   All WInSet files reside in the folder you created during installation.
   Just remove the folder with all its contents. WInSet does not use
   Windows Registry.


LICENSE AGREEMENT

1. WInSet version 3 is bundled with the book
   ======================================================
   Albert D. Morozov, Timothy N. Dragunov.
   Visualization and Analysis of Invariant Sets
   of Dynamical Systems.
   Moscow-Izhevsk: "Institute for Computer Studies", 2003
   (in Russian).
   ======================================================

   There was also previous edition in English 
   ==================================================
   Albert D. Morozov, Timothy N. Dragunov,
   Svetlana A. Boykova, Olga V. Malysheva.
    Invariant Sets for Windows: resonance structures,
    attractors, fractals and patterns.
   World Scientific Ser. Nonlinear Sci., Series A,
   Vol. 37, World Scientific, 1999.
   ==================================================

   The program may be sold only along with one of these books.

   WInSet program by itself may be freely distributed
   and used for educational and scientific purposes
   provided the distribution package and this file are
   not modified.

2. WInSet IS DISTRIBUTED "AS IS". NO WARRANTY OF ANY KIND
   IS EXPRESSED OR IMPLIED. THE AUTHORS WILL NOT 
   BE LIABLE FOR DATA LOSS, DAMAGES, LOSS OF PROFITS OR ANY
   OTHER KIND OF LOSS WHILE USING OR MISUSING THIS SOFTWARE. 

3. Installing and using WInSet signifies acceptance of these
   terms and conditions of the license.

4. If you do not agree with the terms of this license you
   must remove WInSet files from your computer.

5. WInSet authors:

   Timothy N. Dragunov,
   Albert D. Morozov. 

   Olga V. Malysheva and Svetlana A. Boykova
   also worked on WInSet and the book at 1998-1999.


   Nizhny Novgorod State University,
   Institute of Information Technology, Mathematics and Mechanics
   (Former Department of Mechanics and Mathematics),
   Nizhny Novgorod,
   Russia.
   1998-2018.

   Default fractal palette is based on palette from 
   public domain program "Winfract".


Thank you for using WInSet!

   If you like this program and want to remark upon it
   or if you have found a bug, please, feel free to 
   contact us:

   Timothy Dragunov:       dtn@mm.unn.ru 
   Dr. Albert D. Morozov:  morozov@mm.unn.ru

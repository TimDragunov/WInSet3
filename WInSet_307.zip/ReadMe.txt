WInSet: Invariant Sets for Windows

            Version 3.0.7

This file contains the last important
information about installation and usage of WInSet.



WHAT'S NEW in this release

  User systems may include the sign function.



WHAT'S NEW in release 3.0.6

  We added help system in English.



WHAT'S NEW in release 3.0.5

  New type of user-defined system added:
  'Diff. eq.: two oscillators'
  It allows plotting a map for the 1st oscillator
  over the period of the 2nd oscillator.

  Period of oscillations is calculated at the beginning of plotting.
  It depends on additional computation options:
     Time interval for period computation,
     Init. cond. X for 2nd oscillator,
     Init. cond. Y for 2nd oscillator.
  The calculation is performed with zero values of variables
  corresponding to the 1st oscillator. The calculation is
  performed also when system parameters are changed by user.

  User must control "feedback" of the 1st oscillator to the 2nd one,
  i.e. you must set correct values of parameters.
  
  Calculated value of period is displayed in the upper part of 
  the Coordinate panel: "Period=���".
     


WHAT'S NEW in release 3.0.4

  Additional functions may be used in user-defined systems:
  - cbrt: cubic root,
  - rnd:  generator of pseudo-random values in the range 
    from zero to int(a) where a is the argument of function rnd, 
    rnd(a). 

  "Color cycling" option is disabled. This option were used to
  cyclically change palettes in 256-color graphical modes in 
  Windows 95, 98, Me.

  	

WHAT'S NEW in release 3.0.2

  New option added: arbitrary rotation of 3-dimensional plots
  for ODE and maps.

  If the current view is a projection of 3-dimensional plot
  you can press <Ctrl+G> keys to display a separate "3D" window
  which allows you to perform rotation of the plot using
  arrow keys. This window uses OpenGL options: Fog, Perspective,
  Smoothness.

  Before changing plot options in the main window you should 
  close "3D" Window.



WHAT'S NEW in release 3

1. Several built-in systems were added.
   A new option was added for 2D map plots:
   Basins of attraction. 
2. New types of user-defined systems were added:
   - maps on cylinder
   - diff. eq. with 3/2 degrees of freedom on cylinder
   - diff. eq. with 3/2 degrees of freedom on torus
3. Graphics may be saved now as Encapsulated
   PostScript (.EPS). This is not yet implemented
   for PDEs and fractals
4. Boxed axes are now available for 2D plots.
   Menu item "View | Boxed axes" is now checked
   by default.
5. Few bugs of user interface has been fixed.

SYSTEM REQUIREMENTS

1. MS Windows 9X/ME/NT4/2000/...
2. Minimal configuration: i486DX with 32 MB RAM.
   Intel Celeron processor or better recommended.
3. Enough disk space for Windows page file expansion:
   more than 20 Mb.
4. 256 Color video mode or better.

5. Install WInSet into a directory with write
   permission for WInSet users.
    

UNINSTALLING WInSet

1. Use "Add/Remove Programs" icon of
   the Control Panel.
2. All WInSet files reside in the folder
   you specified during installation.


IMPORTANT

   "Color cycling" option which is used to
   anumate fractal pictures is available only 
   for Windows 9X in 256 Color video modes.


LICENSE AGREEMENT

1. WInSet version 3 is bundled with the book
   ======================================================
   Albert D. Morozov, Timothy N. Dragunov.
   Visualization and Analysis of Invariant Sets
   of Dynamical Systems.
   Moscow-Izhevsk: "Institute for Computer Studies", 2003
   (in Russian).
   ======================================================

   There is also previous edition in English 
   ==================================================
   Albert D. Morozov, Timothy N. Dragunov,
   Svetlana A. Boykova, Olga V. Malysheva.
    Invariant Sets for Windows: resonance structures,
    attractors, fractals and patterns.
   World Scientific Ser. Nonlinear Sci., Series A,
   Vol. 37, World Scientific, 1999.
   ==================================================

   The program may be sold only along with one of
   these books.

   WInSet program by itself may be freely distributed
   and used for educational and scientific purposes
   provided the distribution package and this file are
   not modified.

2. WInSet IS DISTRIBUTED "AS IS". NO WARRANTY OF ANY KIND
   IS EXPRESSED OR IMPLIED. THE AUTHORS WILL NOT 
   BE LIABLE FOR DATA LOSS, DAMAGES, LOSS OF PROFITS OR ANY
   OTHER KIND OF LOSS WHILE USING OR MISUSING THIS SOFTWARE. 

3. Installing and using WInSet signifies acceptance of these
   terms and conditions of the license.

4. If you do not agree with the terms of this license you
   must uninstall WInSet and remove WInSet files from your
   computer.

5. WInSet authors:

   Timothy N. Dragunov,
   Albert D. Morozov. 

   Olga V. Malysheva and Svetlana A. Boykova
   also worked on WInSet and the book in 1998-1999.


   Nizhniy Novgorod State University,
   Department of Mechanics and Mathematics,
   Nizhniy Novgorod,
   Russia.
   1998-2003.

   Default fractal palette is based on palette from 
   public domain program "Winfract".



Thank you for using WInSet!

   If you like this program and want to remark upon it
   or if you have found a bug, please, feel free to 
   contact us:

   Timothy Dragunov:       dtn@mm.unn.ru 
   Dr. Albert D. Morozov:  morozov@mm.unn.ru
